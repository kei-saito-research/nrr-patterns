Current snapshot policy:
- The manuscript claim-trace artifacts used by the current manuscript line are committed under `results/`.
- Run-specific ZIP bundles are stored as `results/*.zip`.
- Convenience exports are stored under `results/analysis/`.
- Regenerated manuscript figures are stored under `results/figures/`.
