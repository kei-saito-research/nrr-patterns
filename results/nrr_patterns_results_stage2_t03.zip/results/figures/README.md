Current snapshot policy:
- This directory contains the bundled figure PNG outputs used by the current manuscript line.
- Regenerate them from bundled result artifacts with `python3 generate_nrr_principles_figures.py`.
