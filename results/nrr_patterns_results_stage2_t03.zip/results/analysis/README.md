Current snapshot policy:
- This directory contains bundled convenience CSV exports for the current manuscript line.
- The primary claim-trace sources remain the run-specific ZIP members documented in `reproducibility.md`.
- Regenerate or refresh these exports via `scripts/run_all.sh` and `scripts/run_no_position_ablation.sh`.
